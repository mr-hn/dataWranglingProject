# Required Libraries ------------------------------------------------------
library(tidyverse) # The gas to the caR
library(shiny) # Creating shiny app
library(shinyWidgets) # Extra widgets
library(leaflet) # Mapping zipcodes
library(plotly) # Interactive charts
library(zipcode) # Contains coordinates of all zipcodes

# Data Read ---------------------------------------------------------------
data_zil <- read_csv("data/export_zil.csv")
data_bnb <- read_csv("data/export_bnb.csv")

# Prep for input dropdowns 
avail_years <- data_zil %>% colnames() %>% .[4:ncol(data_zil)]

# DT::datatable render parameters
options(DT.options = list(scrollX = TRUE,    # enable horizontal scrolling
                          scrollY = "calc(20vh)", # enable vertical scrolling - 20% height
                          paging = FALSE))   # disable pagination

# Define UI ---------------------------------------------------------------
ui <- fluidPage(
  shinyUI(navbarPage
          ("Investment Property Recommendations",
            # Overview Tab ---------------------------------------------------------------
            tabPanel("Start Here",
                     column(3, 
                            h4("A break even analysis of short term leasing"),
                            helpText("Filter properties of choice and click on the map 
                                     to see the zipcode's break even period.
                                     Background tab contains more information."),
                            wellPanel( 
                              # Choose State 
                              # pickerInput("state", "State", choices = NULL),
                              selectInput("state", "State", choices = NULL),
                              # Choose City 
                              pickerInput("city", "City/Region", options = list(`actions-box` = TRUE),
                                          choices = NULL, multiple = TRUE, selected = NULL),
                              # Choose ZipCode 
                              pickerInput("zip", "Zip Codes", options = list(`actions-box` = TRUE),
                                          choices = NULL, multiple = TRUE, selected = NULL)
                            ), 
                            wellPanel( 
                              helpText("Home Value Period To Consider"),
                              # Choose Year Range 
                              dateRangeInput("year", label = NULL,
                                             start = avail_years[length(avail_years)], 
                                             end = avail_years[length(avail_years)], 
                                             min = avail_years[1], max = avail_years[length(avail_years)], 
                                             format = "yyyy-MM",startview = "year"),
                              helpText("AirBnB Quantile to Compare Against"),
                              # Choose AirBnB Percentile
                              sliderInput("quantile", label = NULL,
                                          min = 0, max = 100, 
                                          value = 50,
                                          sep = "", step = 10),
                              helpText("Expected occupancy - days in a year"),
                              # Choose Occupancy Rate
                              sliderInput("occupancy", label = NULL,
                                          min = 50, max = 365, 
                                          value = 250,
                                          sep = "", step = 10),
                              helpText("AirBnB Properties to Analyze"),
                              # Choose Bedrooms 
                              selectInput("bedrooms", "Number of Bedrooms", choices = NULL),
                              # Choose Property Type 
                              pickerInput("property", "Property Types", options = list(`actions-box` = TRUE),
                                          choices = NULL, multiple = TRUE, selected = NULL))),
                     mainPanel(
                       # Calculating height - https://stackoverflow.com/a/36471739
                       tags$style(type = "text/css", "#map {height: calc(100vh - 80px) !important;}"),
                       leafletOutput("map", width = "115%")
                     )),
            # Analysis Tab ------------------------------------------------------------
            tabPanel("Analysis",
                     column(3, 
                            wellPanel( 
                              helpText("Of the selected zip codes in the first tab, 
                                       the top n are plotted (controlled through the slider)"),
                              radioButtons("filter_type",
                                           "Choose Sort Order of Zip Codes",
                                           c("Break Even Time" = "low_break",
                                             "Revenue" = "high_rev",
                                             "Property Price" = "low_price"), 
                                           selected = "low_break"),
                              helpText("Hover over the graphs to see more info"),
                              helpText("Click on legends to filter by cities"),
                              br(),
                              sliderInput("count", label = "Number of Zip Codes to Plot",
                                          min = 5, max = 30, 
                                          value = 10,
                                          sep = "", step = 1)
                            )),
                     mainPanel(
                       htmlOutput("radio_title"),
                       br(),
                       tags$style(type = "text/css", "#graph1 {height: calc(50vh - 110px) !important;}"),
                       plotlyOutput("graph1"),
                       br(),
                       p("The distribution of the AirBnB rents for each Zip is plotted below."),
                       br(),
                       tags$style(type = "text/css", "#graph2 {height: calc(50vh - 110px) !important;}"),
                       plotlyOutput("graph2"))
            ),
            # Raw Data Tab ------------------------------------------------------------
            tabPanel("Raw Data",
                     h4("The raw data for the selected zip codes is displayed below."),
                     p("The", tags$b("break even years"), "is calculated from", tags$b("average price"), 
                       "divided by the", tags$b("yearly_revenue")),
                     br(),
                     h4("AirBnB Listings"),
                     p("The", tags$b("quantile"), "field contains the rent for the selected percentile for a zip code."),
                     p(tags$b("yearly_revenue"), "is calculated from the occupancy rate and quantile."),
                     DT::dataTableOutput("airbnb_table"),
                     br(),
                     h4("Zillow Data"),
                     p("All monthly prices selected in the date range earlier are displayed."),
                     p(tags$b("average_price"), "is the mean price for the zipcode, through the selected months."),
                     DT::dataTableOutput("zillow_table")),
            # Background Tab ----------------------------------------------------------
            tabPanel("Background",
                     h4("Peer-to-Peer Market Platform in Real Estate Industry"),
                     p("With shared economy becoming more and more ubiquitous, 
                       one way to keep up with the evolution is to lease investment properties 
                       on a short term basis with services such as AirBnB.
                       This project aims to identify regions that have the highest return on investment."),
                     br(),
                     h4("Approach"),
                     p("For every Zip Code, the median housing value provided by",
                       a("Zillow", href = "https://www.zillow.com/research/data/", target = "_blank"),
                       "is compared against the median daily rentals of properties listed in",
                       a("AirBnB.", href = "http://insideairbnb.com/get-the-data.html", target = "_blank"),
                       "For the selected occupancy rate, the number of years it will take to break even the
                       investment is calculated and plotted on the map as circles. Larger the circle, longer the
                       break even period. Clicking a zip code brings a pop-up with the time of ROI."),
                     br(),
                     h4("Data"),
                     p("For this analysis, only listings in New York city are considered,
                       with the ability to add more cities by including the cities' data.
                       There is another limitation on the house size, with only 2-bedroom 
                       properties taken into consideration."),
                     p("It is to be noted that Zillow housing prices are not available for a vast number of zip codes, 
                       with Bronx being particularly absent in the dataset."),
                     p("To observe the app's behaviour, a few dummy lines for Los Angeles have been added."),
                     br(),
                     h4("Inputs & Filters"),
                     h5("The selections made in the first tab applies to all other tabs"),
                     tags$ul(
                       tags$li(tags$b("State/City/ZipCode"), 
                               p("Choice of regions to filter."),
                               helpText("Currently, the app recommends best zipcodes in NYC. Should the user choose to
                                        explore other cities and regions, these three inputs will play a role.")), 
                       tags$li(tags$b("Home Value Period"), 
                               p("For each zipcode, the median housing value is available for each month, going back 
                                 years. The user is given control to choose the period, which is then averaged to 
                                 estimate the housing value for that zipcode."),
                               helpText("Housing values are enormously dependent on economic fluctuations. By giving
                                        the ability to choose range, the user, if they know past conditions, can 
                                        compare to prices from that period.")), 
                       tags$li(tags$b("AirBnB Quantile"), 
                               p("Gives the ability to choose rental price quantile. For example, when set to 75, 
                                 the 75th percentile rent of each zipcode is used to calculate the yearly revenue of
                                 each zipcode."),
                               helpText("This gives control over what rent the user can hope to charge. If a property is in 
                                        the top 25% in the zipcode, then they can hope to charge the 75th percentile rent.")), 
                       tags$li(tags$b("Expected Occupancy"), 
                               p("Number of days the property is expected to be occupied.Higher the number, quicker 
                                 the break-even."),
                               helpText("A measure of confidence in returns. Helps to estimate best/worst case scenarios.")), 
                       tags$li(tags$b("AirBnB Propeties"), 
                               p("The app currently contains only data for 2-bedroom houses. Analysis will be carried out 
                                 for one house size at a time"), 
                               helpText("The yearly returns and property prices is going to be vastly different depending on 
                                        the number of bedrooms of the property. To ensure different scales are not compared, 
                                        they have to be analyzed individually."),
                               helpText("AirBnB listings contain entire houses and multiple private rooms listed as a 
                                        property. User gets to exclude any, if desired"))),
                     br(),
                     h4("Potential Shortcomings"),
                     h5(tags$b("Data")),
                     p("The data used comes from two sources - Zillow and AirBnB. Zillow does not maintain the median 
                       housing value for a large number of zip codes. Also while the median may be a good measure of the 
                       overall housing market, having a range instead can make the analysis more accurate. Coming to
                       the AirBnB data, the lack of occupancy information makes this analysis widely fluctuating. The
                       size of the property in sq.ft is missing for almost all records and hence unusable."),
                     h5(tags$b("Suppositions")),
                     p("The listed rent on AirBnB depends on a large number of factors - vicinity to attractions,
                       public transportation, experiences offerred, etc. In fact, the pictures of the listing", 
                       "play the largest role when choosing a place. None of these have been considered. One way to do 
                       it would be doing text analysis on the description of the listings. Taking the review score into
                       account, and the host ratings could also improve the estimated rent."),
                     h5(tags$b("Business Concerns")),
                     p("The state of the economy, or the discount rate of money has not been taken into account.
                       Since short term renting services rely heavily on people traveling, the effect of recessions
                       could be devastating. Also, AirBnB, and by extension the other rental services, have a long history
                       of", a("controversies.", href = "en.wikipedia.org/wiki/Airbnb#Controversies", target = "_blank"),
                       "The investment could turn unfavorable, should policies be made against these services.")
            ))))

# Server ------------------------------------------------------------------
server <- function(input, output, session) { 
  
  # Update inputs based on other input selections ---------------------------
  # State from data file
  # Gather data
  input_state <- reactive({
    data_bnb %>% distinct(state) %>% arrange(desc(state))
  })
  observe({
    # Update
    updatePickerInput(session = session,
                      inputId = "state",
                      choices = input_state()$state)
  })
  # City based on selected state
  input_city <- reactive({
    data_bnb %>% filter(state == input$state) %>% distinct(city) %>% arrange(city)
  })
  observe({
    updatePickerInput(session = session,
                      inputId = "city",
                      choices = input_city()$city,
                      selected = input_city()$city)
  })
  # Zip code based on selected state and city
  input_zip <- reactive({
    req(input$city)
    data_bnb %>% filter(state == input$state &
                          city %in% input$city
    ) %>% 
      distinct(zipcode) %>% arrange(zipcode)
  })
  observe({
    updatePickerInput(session = session,
                      inputId = "zip",
                      choices = input_zip()$zipcode,
                      selected = input_zip()$zipcode)
  })
  # Number of bedrooms for the zipcode
  input_bedrooms <- reactive({
    data_bnb %>% filter(state == input$state &
                          city %in% input$city &
                          zipcode %in% input$zip) %>% 
      distinct(bedrooms) %>% arrange(bedrooms)
  })
  observe({
    updateSelectInput(session = session,
                      inputId = "bedrooms",
                      choices = input_bedrooms()$bedrooms)
  })
  # Property Type for the zipcode
  input_property <- reactive({
    data_bnb %>% filter(state == input$state &
                          city %in% input$city &
                          zipcode %in% input$zip) %>% distinct(property_type)
  })
  observe({
    updatePickerInput(session = session,
                      inputId = "property",
                      choices = input_property()$property_type,
                      selected = input_property()$property_type)
  })
  
  # Data Prep ---------------------------------------------------------------
  # Apply filters on Zillow data and store - Raw Data 1
  data_zil_filtered <- reactive({
    
    data_zil$zipcode <- as.character(data_zil$zipcode)
    
    # Get the month-year range input selected 
    start_month <- format(input$year[1], "%Y-%m")
    end_month <- format(input$year[2], "%Y-%m")
    # Get column number to select `through` the columns
    start_month_n <- which(colnames(data_zil) == start_month)
    end_month_n <- which(colnames(data_zil) == end_month)
    
    # Calculate property mean price based on range selected
    data_zil$average_price <- rowMeans(subset(data_zil, select = start_month_n:end_month_n), 
                                       na.rm = TRUE) %>% round(0)
    
    # Filter
    data_zil %>% filter(state == input$state &
                          zipcode %in% input$zip & 
                          bedrooms == input$bedrooms) %>% 
      select(state, zipcode, average_price, start_month_n:end_month_n) %>% 
      arrange(state, zipcode)
  })
  # Render filtered Zillow raw data
  output$zillow_table <- DT::renderDataTable({
    data_zil_filtered() %>% 
      DT::datatable(rownames = FALSE) 
  })  
  
  # Apply filters on AirBnB data and store  - Raw Data 2
  data_bnb_filtered <- reactive({
    
    data_bnb$zipcode <- as.character(data_bnb$zipcode)
    
    # Apply filters
    data_bnb %>% filter(state == input$state & 
                          city %in% input$city &
                          zipcode %in% input$zip &
                          bedrooms == input$bedrooms &
                          property_type %in% input$property) %>% 
      group_by(state, city, zipcode, bedrooms) %>% 
      # Calculate quantile price
      mutate(quantile = quantile(price, input$quantile / 100),
             # Calculate yearly revenue
             yearly_revenue = input$occupancy * quantile) %>% 
      select(state, city, zipcode, bedrooms, property_type, price, quantile, yearly_revenue) %>% 
      arrange(state, zipcode, desc(price))
  })
  # Render filtered Zillow data 
  output$airbnb_table <- DT::renderDataTable({
    data_bnb_filtered() %>% 
      DT::datatable(rownames = FALSE) 
    # formatStyle(columns = colnames(data_bnb_filtered()), backgroundColor = "#060606")
  })
  
  
  # Combined data for the map and graphs ------------------------------------
  data_bnb_unique <- reactive({
    
    #Coordinates for zipcode loaded
    data(zipcode, package = "zipcode")
    
    data_bnb_filtered() %>% 
      # Collect data for each zip
      distinct(state, city, zipcode, bedrooms, quantile, yearly_revenue) %>%
      inner_join(zipcode[,c(1,4,5)], by = c("zipcode" = "zip")) %>% 
      inner_join(data_zil_filtered()[,c(2,3)], by = "zipcode") %>% 
      select(state, city, zipcode, bedrooms, latitude, longitude, quantile, yearly_revenue, average_price) %>% 
      # Calculate break-even time
      mutate(break_even_years = round(average_price / yearly_revenue))
  })
  
  # Render map --------------------------------------------------------------
  output$map <- renderLeaflet({
    req(input$zip)
    # Render map and zoom to first selected zipcode
    leaflet() %>%
      addTiles(
        # Black map background
        # urlTemplate = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
        urlTemplate = "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
        attribution = 'Maps by <a href="https://carto.com/attributions", target = "_blank">Carto</a>'
      ) %>%
      # Set zoom to the first selected zip code
      setView(lng = zipcode[zipcode$zip == input$zip[1], 5],
              lat = zipcode[zipcode$zip == input$zip[1], 4], zoom = 11)
  })
  
  # Plot break-even data as circles
  observe({
    leafletProxy("map", data = data_bnb_unique()) %>%
      clearShapes() %>%
      # Add circles for break-even years
      addCircles(lng = ~longitude,
                 lat = ~latitude,
                 color = "#025791",
                 # Multiplied by 15 to make the cirlce better visible
                 radius = ~(break_even_years * 15),
                 layerId = ~zipcode) 
  })   
  
  # Function to show pop-up
  # Takes the clicked zipcode, lat and long as inputs
  show_pop_up <- function(zipcode, lat, lng) {
    
    # Get data for the clicked zip
    calculated_data <- data_bnb_unique()
    clicked_zip <- calculated_data[calculated_data$zipcode == zipcode,]
    
    # Build and display HTML popup
    content <- as.character(tagList(
      tags$h4(as.integer(clicked_zip$zipcode), "-", clicked_zip$city),
      tags$h5("Break Even Years:", as.integer(clicked_zip$break_even_years)),
      tags$h5("Yearly Revenue:", as.integer(clicked_zip$yearly_revenue)),
      tags$h5("Median Housing value:", as.integer(clicked_zip$average_price))
    ))
    leafletProxy("map") %>% addPopups(lng, lat, content, layerId = zipcode)
  }
  
  # Capturing the click and calling the function for pop-up
  observe({
    leafletProxy("map") %>% clearPopups()
    event <- input$map_shape_click
    if (is.null(event))
      return()
    isolate({
      # Call function
      show_pop_up(event$id, event$lat, event$lng)
    })
  })
  
  # Contents in Analysis Tab ------------------------------------------------
  # A helper text to indicate what the radio button selection could imply
  output$radio_title <- renderText({
    req(input$filter_type)
    if (input$filter_type == "low_break") {
      paste("<h4>When the objective is to take back the principal in the shortest period</h4>",
            "The Zip Codes with the lowest break even time are displayed.",
            "<i>The calculation depends upon the home value date range, expected 
            occupancy, and AirBnB rent quantile.</i>")
    } else if (input$filter_type == "high_rev") {
      paste("<h4>When the objective is to get high 'interest rate'</h4>",
            "The Zip Codes that have the highest rent on AirBnB are displayed.",
            "<i>The calculation depends upon expected occupancy and AirBnB rent quantile.</i>")
    } else if (input$filter_type == "low_price") {
      paste("<h4>When the objective is to invest minimum</h4>",
            "The Zip Codes that have the lowest median housing price are displayed.",
            "<i>The calculation depends upon the home value date range.</i>")
    } 
  })
  
  # Apply sort and choose top n based on the radio button and slider
  data_bnb_unique_sorted <- reactive({
    req(input$filter_type, input$count)
    
    data_bnb_unique_sorted <- data_bnb_unique()
    
    if (input$filter_type == "low_break") {
      data_bnb_unique_sorted %>% arrange(break_even_years) %>% head(input$count)
    } else if (input$filter_type == "high_rev") {
      data_bnb_unique_sorted %>% arrange(yearly_revenue) %>% tail(input$count)
    } else if (input$filter_type == "low_price") {
      data_bnb_unique_sorted %>% arrange(average_price) %>% head(input$count)
    } 
  })
  
  # Charts ------------------------------------------------------------------
  # Change chart 1 based on selected radio button
  output$graph1 <- renderPlotly({
    
    req(input$filter_type)
    data_bnb_unique_sorted <- data_bnb_unique_sorted()
    # Button 1
    if (input$filter_type == "low_break") {
      
      data_bnb_unique_sorted %>% 
        plot_ly(x = ~zipcode, y = ~break_even_years, type = "bar",
                hoverinfo = "text",
                text = ~paste(zipcode, "-", city, "\n",
                              "Break Even Years: ", break_even_years, "\n",
                              "Yearly Revenue: ", yearly_revenue, "\n",
                              "Median Housing value: ", average_price),
                color = ~city) %>% 
        # Ensuring zipcode is treated as a ordered factor
        layout(xaxis = list(title = "Zip Code",
                            categoryorder = "array",
                            categoryarray = data_bnb_unique_sorted$zipcode),
               yaxis = list(title = "Years"),
               title = "Break Even Year") %>% 
        config(displayModeBar = F)
    }
    # Button 2
    else if (input$filter_type == "high_rev") {
      
      data_bnb_unique_sorted %>% 
        plot_ly(x = ~zipcode, y = ~yearly_revenue, type = "bar",
                hoverinfo = "text",
                text = ~paste(zipcode, "-", city, "\n",
                              "Break Even Years: ", break_even_years, "\n",
                              "Yearly Revenue: ", yearly_revenue, "\n",
                              "Median Housing value: ", average_price),
                # color = ~average_price, colors = c("#55AAFF", "#2C5988")) %>%
                color = ~city) %>%
        layout(xaxis = list(title = "Zip Code",
                            categoryorder = "array",
                            categoryarray = data_bnb_unique_sorted$zipcode),
               yaxis = list(title = "Yearly Revenue in $"),
               title = "Yearly Revenue") %>% 
        hide_colorbar() %>% config(displayModeBar = F)
    } 
    # Button 3
    else if (input$filter_type == "low_price") {
      
      data_bnb_unique_sorted %>% 
        plot_ly(x = ~zipcode, y = ~average_price, type = "bar",
                hoverinfo = "text",
                text = ~paste(zipcode, "-", city, "\n",
                              "Break Even Years: ", break_even_years, "\n",
                              "Yearly Revenue: ", yearly_revenue, "\n",
                              "Median Housing value: ", average_price),
                # color = ~yearly_revenue, colors = c("#55AAFF", "#2C5988")) %>%
                color = ~city) %>%
        layout(xaxis = list(title = "Zip Code",
                            categoryorder = "array",
                            categoryarray = data_bnb_unique_sorted$zipcode),
               yaxis = list(title = "Housing Price in $"),
               title = "Median Housing Price") %>% 
        hide_colorbar() %>% config(displayModeBar = F)
    } 
  })
  
  # Chart 2
  output$graph2 <- renderPlotly({
    
    # Fetch all AirBnb listings for selected zipcodes
    data_bnb_filtered <- data_bnb_filtered() 
    # And the order of the selected zipcode, with top n
    data_bnb_unique_sorted <- data_bnb_unique_sorted()
    
    # Ensuring data is available
    if (nrow(data_bnb_unique_sorted) > 0) {
      
      # Fetch all AirBnb listings for top n zip codes
      data_bnb_filtered <- data_bnb_filtered %>% 
        inner_join(data_bnb_unique_sorted, by = "zipcode")
      # Match sort order
      data_bnb_filtered$zipcode <- factor(data_bnb_filtered$zipcode, 
                                          levels = data_bnb_unique_sorted[["zipcode"]])
      # Unable to implement in plotly - ggplotly is used instead
      p <-  ggplot(data_bnb_filtered, aes(x = zipcode, y = price)) + 
        geom_boxplot(aes(fill = city.x, color = city.x)) + theme_minimal() +
        xlab("") + ylab("Daily rent in $") +
        theme(panel.grid.minor.x = element_blank(),
              panel.grid.major.x = element_blank(),
              legend.title = element_blank())
      
      ggplotly(p) %>% config(displayModeBar = F) 
    }
  })
}

# Run the application -----------------------------------------------------
shinyApp(ui = ui, server = server)