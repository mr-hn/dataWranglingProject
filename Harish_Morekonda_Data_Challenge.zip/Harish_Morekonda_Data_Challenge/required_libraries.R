# Function to list/install libraries that are unavailable

# Reads from ~data/required_libraries.txt
# Each library is expected in a separate line with a blank line feed at the end

req_libraries <- function(install = FALSE) {
  
  libraries <- read.table("data/required_libraries.txt")
  
  # Collect unavailable libraries
  unavail_lib <- setdiff(libraries$V1, rownames(installed.packages()))
  
  # If any exists
  if (length(unavail_lib) != 0) {
    
    # Collect unavailable libraries - To print as string
    unavail_lib_str <- paste0(sprintf("'%s'", unavail_lib), collapse = ", ")
    
    # Check if install argumnent is passed
    if (install == FALSE) {
      # Message packages
      message_text <- paste0("\n \nThe following libraries are not installed \n",
                             "Please copy and run the command below\n \n",
                             "install.packages(c(",
                             unavail_lib_str,
                             "))")
    } 
    else{#(install == TRUE)
      # Install and message packages
      install.packages(unavail_lib)
      message_text <- paste0("The following packages were installed - \n", unavail_lib_str)
    }
  }
  else {#length(unavail_lib) == 0
    message_text <- "All libraries are already installed"
  }
  # Output message
  message(message_text)
}


# Install missing packages if any
# req_libraries(install = TRUE)

# Output missing packages as a message
req_libraries(install = FALSE)